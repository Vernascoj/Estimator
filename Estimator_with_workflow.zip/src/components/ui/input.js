import React from 'react';

// Stub Input
export function Input(props) {
  return <input {...props} />;
}
